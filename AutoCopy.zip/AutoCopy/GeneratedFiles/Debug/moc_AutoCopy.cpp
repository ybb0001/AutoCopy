/****************************************************************************
** Meta object code from reading C++ file 'AutoCopy.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../AutoCopy.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'AutoCopy.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_AutoCopy_t {
    QByteArrayData data[11];
    char stringdata0[225];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AutoCopy_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AutoCopy_t qt_meta_stringdata_AutoCopy = {
    {
QT_MOC_LITERAL(0, 0, 8), // "AutoCopy"
QT_MOC_LITERAL(1, 9, 30), // "on_pushButton_Minimize_clicked"
QT_MOC_LITERAL(2, 40, 0), // ""
QT_MOC_LITERAL(3, 41, 23), // "on_activatedSysTrayIcon"
QT_MOC_LITERAL(4, 65, 33), // "QSystemTrayIcon::ActivationRe..."
QT_MOC_LITERAL(5, 99, 6), // "reason"
QT_MOC_LITERAL(6, 106, 17), // "on_showMainAction"
QT_MOC_LITERAL(7, 124, 16), // "on_exitAppAction"
QT_MOC_LITERAL(8, 141, 27), // "on_pushButton_Start_clicked"
QT_MOC_LITERAL(9, 169, 28), // "on_pushButton_Manual_clicked"
QT_MOC_LITERAL(10, 198, 26) // "on_pushButton_Save_clicked"

    },
    "AutoCopy\0on_pushButton_Minimize_clicked\0"
    "\0on_activatedSysTrayIcon\0"
    "QSystemTrayIcon::ActivationReason\0"
    "reason\0on_showMainAction\0on_exitAppAction\0"
    "on_pushButton_Start_clicked\0"
    "on_pushButton_Manual_clicked\0"
    "on_pushButton_Save_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AutoCopy[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   49,    2, 0x08 /* Private */,
       3,    1,   50,    2, 0x08 /* Private */,
       6,    0,   53,    2, 0x08 /* Private */,
       7,    0,   54,    2, 0x08 /* Private */,
       8,    0,   55,    2, 0x08 /* Private */,
       9,    0,   56,    2, 0x08 /* Private */,
      10,    0,   57,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void AutoCopy::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        AutoCopy *_t = static_cast<AutoCopy *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_Minimize_clicked(); break;
        case 1: _t->on_activatedSysTrayIcon((*reinterpret_cast< QSystemTrayIcon::ActivationReason(*)>(_a[1]))); break;
        case 2: _t->on_showMainAction(); break;
        case 3: _t->on_exitAppAction(); break;
        case 4: _t->on_pushButton_Start_clicked(); break;
        case 5: _t->on_pushButton_Manual_clicked(); break;
        case 6: _t->on_pushButton_Save_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject AutoCopy::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_AutoCopy.data,
      qt_meta_data_AutoCopy,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *AutoCopy::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AutoCopy::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_AutoCopy.stringdata0))
        return static_cast<void*>(const_cast< AutoCopy*>(this));
    return QWidget::qt_metacast(_clname);
}

int AutoCopy::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
